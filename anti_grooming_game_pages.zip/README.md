# Góc An Toàn Online — Trò chơi nhận diện Grooming (GitHub Pages)

## Cách triển khai nhanh (không cần code)
1) Tạo repo **Public** trên GitHub (ví dụ: `anti-grooming-game`).
2) Tải 3 file sau lên repo (đặt ở thư mục gốc): `index.html`, `.nojekyll` (file rỗng).
3) Vào **Settings → Pages**:
   - Build and deployment: **Deploy from a branch**
   - Branch: **main**  / **/** (root)
   - Save
4) Link sẽ có dạng: `https://<tài-khoản>.github.io/anti-grooming-game/`.

> Nếu muốn dùng domain gốc: đặt repo tên `<username>.github.io`.

## Gợi ý
- Nếu thêm thư mục `assets/` (ảnh/âm thanh), sử dụng **đường dẫn tương đối** như `assets/sound.mp3`.
- Nếu có SPA/router, hãy thêm `404.html` copy từ `index.html`.
- Nên giữ mã Unicode UTF-8.
